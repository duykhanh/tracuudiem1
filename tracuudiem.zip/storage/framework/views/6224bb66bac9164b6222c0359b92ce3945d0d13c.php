<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(URL::asset('js/search.js')); ?>" type="text/javascript"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="content-wrapper" >
    <?php if($type=='2'): ?>
    <h4>Tra Cứu Văn Bằng</h4>
    <?php else: ?>
    <h4>Tra Cứu Điểm Thi</h4>
    <?php endif; ?>
    <div ng-controller="searchController">

        <div class="search-form-fillter" loading="">
            <div class="form-fillter-controls">
                <?php if($type=='2'): ?>
                <label class="control-label">Chọn Năm Tốt Nghiệp</label>
                <?php else: ?>
                <label class="control-label">Chọn Đợt Thi</label>
                <?php endif; ?>
                <select class="form-control" ng-model="selectedCourse" ng-change="getColInfo()">
                    <?php if($type=='2'): ?>
                    <option value="-1">--Năm tốt nghiệp--</option>
                    <?php else: ?>
                    <option value="-1">---Đợt thi--</option>
                    <?php endif; ?>
                    <?php foreach($exams as $course): ?> 
                    <option value="<?php echo e($course['id']); ?>"><?php echo e($course['decs']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div ng-show="isShowSearchForm" class="search-form" >
                <hr/>
                <div class="table-responsive">

                    <form name="searchForm">

                        <?php if($type=='1'): ?>
                        <table>
                            <tr>
                                <td >
                                    <label class="control-label">Số Báo Danh</label>
                                </td>
                                <td>
                                    <input type="text" class="form-control" name="hoten" id="sbd" ng-model="sbd" ng-pattern="regexForNumber">
                                    <div ng-messages="searchForm.sbd.$error" class="error-messages">                                        
                                        <span class="inline-error" ng-message="pattern">Chỉ nhập số 0-9</span>
                                    </div>
                                </td>
                                <td>
                                    <label class="control-label">Họ Và Tên</label>
                                </td>
                                <td>
                                    <input type="text" class="form-control" name="hoten" id="hoten" ng-model="hoten" ng-pattern="regexForSpecChar" >
                                    <div ng-messages="searchForm.hoten.$error" class="error-messages">                                        
                                        <span class="inline-error" ng-message="pattern">Không cho phép nhập ký tự đặc biệt</span>
                                    </div>
                                </td>
                            </tr>
                            <tr>

                                <td class="btn-container" colspan="4">
                                    <hr/>
                                    <input type="button" ng-click="searchMark()" value="Tìm Kiếm" class="btn btn-primary">
                                </td>
                            </tr>
                        </table>
                        <?php else: ?>
                        <table>
                            <tr>
                                <td class="required">
                                    <label class="control-label">Họ Và Tên</label>
                                </td>
                                <td>
                                    <input type="text" class="form-control" name="hoten" id="hoten" ng-model="hoten" ng-pattern="regexForSpecChar" required>
                                    <div ng-messages="searchForm.hoten.$error" class="error-messages">
                                        <span class="inline-error" ng-message="required">Họ và tên không được rỗng</span>
                                        <span class="inline-error" ng-message="pattern">Không cho phép nhập ký tự đặc biệt</span>
                                    </div>
                                </td>
                                <td class="required">
                                    <label class="control-label">Ngày Sinh</label>
                                </td>
                                <td>
                                    <input type="text" class="form-control" id="ngaysinh" name="ngaysinh" ng-model="ngaysinh" ng-pattern="regexForDateTime" placeholder="dd/mm/yyyy" required>
                                    <div ng-messages="searchForm.ngaysinh.$error" class="error-messages">
                                        <span class="inline-error" ng-message="required">Ngày sinh không được rỗng</span>
                                        <span class="inline-error" ng-message="pattern">Ngày sinh không hợp lệ</span>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <label class="control-label">Số Vào Sổ</label>
                                </td>
                                <td>
                                    <input type="text" class="form-control" id="svso" ng-model="sovaoso">
                                </td>
                                <td>
                                    <label class="control-label">Hội Đồng Thi</label>
                                </td>
                                <td>
                                    <input type="text" class="form-control" id="hdthi" ng-model="hdthi">
                                </td>
                            </tr>

                            <tr>
                                <td class="btn-container" colspan="4">
                                    <hr/>
                                    <input type="button" ng-click="searchCert()" value="Tìm Kiếm" class="btn btn-primary">
                                </td>
                            </tr>
                        </table>
                        <?php endif; ?>
                    </form>

                </div>

            </div>
        </div>

        <div  ng-show="isShowSearchResult" class="search-result table-responsive">
            <table class="table table-custom">
                <thead>
                    <tr>                        
                        <th ng-repeat="colField in colFields"><%colField.fielddecs%></th>
                    </tr>
                </thead>
                <tbody>
                    <tr ng-if="searchResult.length > 0" ng-repeat="user in searchResult">
                        <td ng-repeat="value in user"><%value%></td>
                    </tr>
                    <tr ng-if="searchResult.length === 0" >
                        <td>Không Tìm Thấy Thông Tin</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>