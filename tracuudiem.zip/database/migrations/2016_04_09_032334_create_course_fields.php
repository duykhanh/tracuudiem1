<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateCourseFields extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
         Schema::create('course_fields', function (Blueprint $table) {
            $table->increments('id');
            $table->string('ccode');
            $table->string('fieldname');
            $table->string('fielddecs');        
			$table->timestamps();			
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
         Schema::drop('exam_courses');
    }
}
