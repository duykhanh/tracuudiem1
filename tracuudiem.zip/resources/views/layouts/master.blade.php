<!DOCTYPE html>
<html>
    <head >
        <title>Tra cứu điểm</title>

        <meta content="text/html; charset=UTF-8" http-equiv="content-type">

        <link href="http://danang.edu.vn/Sgddt-th-portlet/images/favicon.ico" rel="Shortcut Icon">
        <link href="{{URL::asset('css/bootstrap.min.css')}}" rel="stylesheet" type="text/css">
        <link href="{{URL::asset('css/fontawesome/font-awesome.min.css')}}" rel="stylesheet" type="text/css">
        <link href="{{URL::asset('css/app.css')}}" rel="stylesheet" type="text/css">
        <script src="{{URL::asset('js/jquery-1.12.2.min.js')}}" type="text/javascript"></script>
        <script src="{{URL::asset('js/angular.min.js')}}" type="text/javascript"></script>
        <script src="{{URL::asset('js/angular-messages.min.js')}}" type="text/javascript"></script>
        <script src="{{URL::asset('js/angular-sanitize.min.js')}}" type="text/javascript"></script>
        <script src="{{URL::asset('js/bootstrap.min.js')}}" type="text/javascript"></script>        
        <script type="text/javascript">
var BASIC_URL = "<?php echo URL::to('/'); ?>";
        </script>
        <script src="{{URL::asset('js/app.js')}}" type="text/javascript"></script>
        @yield('scripts')
    </head>
    <body ng-app="searchModule" >
        <div class="main-container" >
            <header>
                <div class="flash-wrapper">
                    <div class="flash-banner">
                        <object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,19,0" width="720" height="136">
                            <param name="movie" value="{{URL::asset('images//gddt1.swf')}}">
                            <param name="quality" value="high">
                            <param name="wmode" value="transparent">
                            <param name="play" value="true" />
                            <embed src="{{URL::asset('images//gddt1.swf')}}" quality="high" wmode="transparent" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" width="720" height="136">
                        </object>
                    </div>
                </div>
                <div class="nav-wrapper ">
                    <ul class="nav navbar-nav-custom">
                        <li class="active"><a href="http://danang.edu.vn/"><i class="fa fa-home" aria-hidden="true"></i></a></li>
                        <li><a href="{{ URL::to('/cert/2') }}">Tra Cứu Văn Bằng</a></li>
                        <li><a href="{{ URL::to('/cert/1') }}">Tra Cứu Điểm Thi</a></li> 
                        <li><a href="{{ URL::to('/setting') }}">Quản Trị</a></li> 

                    </ul>
                    <ul class="nav navbar-float-right">
                        @if(auth()->guest())
                        <li><a href="{{ URL::to('/auth/login') }}">Login</a></li> 
                        @else
                        <li><a href="{{ URL::to('/auth/logout') }}">Logout</a></li> 
                        @endif
                    </ul>


                </div>
            </header>
            <div class="main-content" >
                @yield('content')
            </div>
            <footer>
                <div class="nav-bottom">
                    <a>Trang Chủ</a>
                    <a>Liên Hệ</a>
                    <a href="/so-do-site">Sơ đồ Website</a>
                    <a><i class="fa fa-rss-square" aria-hidden="true"></i>Rss</a>				
                </div>

                <div class="footer-content">
                    <p>Sở Giáo dục và Đào tạo thành phố Đà Nẵng</p>
                    <p> Tầng 21 Trung tâm hành chính Thành phố Đà Nẵng, 24 Trần Phú, phường Thạch Thang, quận Hải Châu, Thành phố Đà Nẵng</p>
                    <p> Email: <a href="mailto:vanphong.sodanang@moet.edu.vn">vanphong.sodanang@moet.edu.vn</a></p>
                </div>
            </footer>
        </div>

    </body>
</html>
