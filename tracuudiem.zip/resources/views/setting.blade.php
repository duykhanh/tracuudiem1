@extends('layouts.master')
@section('scripts')
<script src="{{URL::asset('js/gen-table.js')}}" type="text/javascript"></script>
@stop
@section('content')


<div class="content-wrapper" ng-controller="genTableCtrl">
    <h4>CẬP NHẬT THÔNG TIN ĐỢT THI HOẶC VĂN BẰNG</h4>
    <hr/>
    <div loading="">
        <div ng-show="isShowErrMgs" class="alert alert-danger">
            <strong>Whoops!</strong> Xảy ra một số lỗi trong quá trình nhập liệu.<br><br>
            <ul>
                <li ng-repeat="err in errMgs" ng-bind-html="err"></li>                
            </ul>
        </div>
        
        <form ng-show="isShowfrmCreateTN" class="form-inline cus-form-inline" name="frmCreateTN" novalidate>
            <div class="form-group">
                <label ng-if="typeOfTable === '1'" for="tableName">Tên Đợt Thi</label>
                <label ng-if="typeOfTable === '2'" for="tableName">Năm Tốt Nghiệp</label>
                <input type="text" class="form-control" name="tableName" id="tableName" placeholder="" ng-pattern="regexForTN"  ng-model="tableName" required="" />
                <label class="radio-inline">
                    <input type="radio" ng-model="typeOfTable" name="optradio" value="1">Đợt Thi
                </label>
                <label class="radio-inline">
                    <input type="radio" ng-model="typeOfTable" name="optradio" value="2">Văn Bằng
                </label>
            </div>

            <button type="button" ng-click="addTableName()" class="btn btn-primary" ng-disabled="frmCreateTN.$invalid || frmCreateTN.input.$invalid">Tạo Tên Bảng</button>

        </form>
        <form name="frmAddCols" ng-show="isShowfrmAddCol" class="table-warrper">
            <p ng-show="isExistColField">Ten cot khong cho phep trung</p>
            <table class="table">
                <thead>
                    <tr>
                        <th>Tên Trường</th>
                        <th>Tên Hiển Thị</th>
                        <th>Kiểu Dữ Liệu</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <tr ng-repeat="colField in colFields track by $index">

                        <td>
                            <%colField.feildName%>
                        </td>

                        <td>
                            <%colField.feildDesc%>
                        </td>

                        <td>
                            <%getFieldName(colField.feildType)%>

                        </td>

                        <td><input type="button" class="btn btn-primary btn-sm" ng-click="deleteField($index)" value="Xóa"/></td>
                    </tr>

                    <tr>

                        <td>
                            <div class="control-group">
                                <input class="form-control" type="text" name="feildName" ng-model="feildName" required/>
                            </div>
                        </td>

                        <td>
                            <div class="control-group">
                                <input class="form-control" type="text" ng-model="feildDesc" ng-pattern="" required>
                                <span class="col-xs-12"></span>
                            </div>
                        </td>

                        <td>
                            <select name="feildType" id="feildType" class="form-control" ng-model="feildType">
                                <option ng-repeat="dataType in dataTypes" value="<%dataType.id%>">
                                    <%dataType.label%>
                                </option>
                            </select>
                        </td>

                        <td>
                            <input ng-disabled="!isValidColN || frmAddCols.feildDesc.$invalid || frmAddCols.$invalid" ng-click="addCollumn()" type="button" value="Thêm trường" class="btn btn-primary" />
                        </td>
                    </tr>
                </tbody>
            </table>
            <hr/>
            <button type="button"  ng-disabled="!isSave()" ng-click="saveTable()" class="btn btn-primary">Lưu Bảng</button>

        </form>

        <form ng-show="isShowfrmImportExcel" name="frmImportExcel" class="form-import">
            <div class="form-group">
                <div class="col-xs-12"><h4>Chon Tập Tin</h4></div>
                <div class="col-xs-12">
                    <div class="input-group">
                        <span class="input-group-btn">
                            <span class="btn btn-primary btn-file">
                                Browse&hellip; <input type="file" file-model="myFile">
                            </span>
                        </span>
                        <input type="text" value="<%filePath%>" class="form-control" readonly>

                        <input ng-disabled="!isValidFile" type="button" ng-click="uploadFile()" value="Đăng Tải" class="btn btn-primary btn-import" />
                    </div>
                    <input type="hidden" name="_token"  value="{{ csrf_token()}}" />
                    <span ng-show="!isValidFile" class="help-block">
                        Cho phép đăng tải tâp tin có định dạng của phần mở rộng .xlsx hoặc .xls
                    </span>
                </div>

            </div>
        </form>

        
    </div>



</div>
@stop
