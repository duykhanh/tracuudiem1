@extends('layouts.master')
@section('scripts')
<script src="{{URL::asset('js/search-cert.js')}}" type="text/javascript"></script>
@stop
@section('content')

<div class="content-wrapper" ng-app="searchModule">
    <h4>Tra Cứu Điểm</h4>
    <div ng-controller="searchController">

        <div class="search-form-fillter">
            <div class="form-fillter-controls"><?php echo "Khfdsf". $type ;?>
                @if($type=='2')
                <label class="control-label">Chọn Năm Tốt Nghiệp</label>
                @else
                <label class="control-label">Chọn Đợt Thi</label>
                @endif
                <select class="form-control" ng-model="selectedCourse" ng-change="getColInfo()">
                    <option value="-1">-Năm tốt nghiệp-</option>
                    @foreach ($exams as $course) 
                    <option value="{{$course['id']}}">{{$course['decs']}}</option>
                    @endforeach
                </select>
            </div>

            <div ng-show="isShowSearchForm" class="search-form">
                <hr/>
                <div class="table-responsive">
                    <form name="searchForm">
                        <table>
                            <tr>
                                <td class="required">
                                    <label class="control-label">Họ Và Tên</label>
                                </td>
                                <td>
                                    <input type="text" class="form-control" name="hoten" id="hoten" ng-model="hoten" ng-pattern="regexForSpecChar" required>
                                    <div ng-messages="searchForm.hoten.$error" class="error-messages">
                                        <span class="inline-error" ng-message="required">Họ và tên không được rỗng</span>
                                        <span class="inline-error" ng-message="pattern">Không cho phép nhập ký tự đặc biệt</span>
                                    </div>
                                </td>
                                <td class="required">
                                    <label class="control-label">Ngày Sinh</label>
                                </td>
                                <td>
                                    <input type="text" class="form-control" id="ngaysinh" name="ngaysinh" ng-model="ngaysinh" ng-pattern="regexForDateTime" placeholder="dd/mm/yyyy" required>
                                    <div ng-messages="searchForm.ngaysinh.$error" class="error-messages">
                                        <span class="inline-error" ng-message="required">Ngày sinh không được rỗng</span>
                                        <span class="inline-error" ng-message="pattern">Ngày sinh không hợp lệ</span>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <label class="control-label">Số Vào Sổ</label>
                                </td>
                                <td>
                                    <input type="text" class="form-control" id="svso" ng-model="sovaoso">
                                </td>
                                <td>
                                    <label class="control-label">Hội Đồng Thi</label>
                                </td>
                                <td>
                                    <input type="text" class="form-control" id="hdthi" ng-model="hdthi">
                                </td>
                            </tr>

                            <tr>
                                <td class="btn-container" colspan="4">
                                    <hr/>
                                    <input type="button" ng-click="searchCert()" value="Tìm Kiếm" class="btn btn-primary">
                                </td>
                            </tr>
                        </table>
                    </form>

                </div>

            </div>
        </div>

        <div  ng-show="isShowSearchResult" class="search-result">
            <table class="table table-custom">
                <thead>
                    <tr>                        
                        <th ng-repeat="colField in colFields"><%colField.fielddecs%></th>
                    </tr>
                </thead>
                <tbody>
                    <tr ng-repeat="user in searchResult">
                        <td ng-repeat="value in user"><%value%></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>

</div>

@stop
