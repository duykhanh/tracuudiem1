@extends('layouts.master')
@section('scripts')
<script src="{{URL::asset('js/search.js')}}" type="text/javascript"></script>
@stop
@section('content')

<div class="content-wrapper" >
    @if($type=='2')
    <h4>Tra Cứu Văn Bằng</h4>
    @else
    <h4>Tra Cứu Điểm Thi</h4>
    @endif
    <div ng-controller="searchController">

        <div class="search-form-fillter" loading="">
            <div class="form-fillter-controls">
                @if($type=='2')
                <label class="control-label">Chọn Năm Tốt Nghiệp</label>
                @else
                <label class="control-label">Chọn Đợt Thi</label>
                @endif
                <select class="form-control" ng-model="selectedCourse" ng-change="getColInfo()">
                    @if($type=='2')
                    <option value="-1">--Năm tốt nghiệp--</option>
                    @else
                    <option value="-1">---Đợt thi--</option>
                    @endif
                    @foreach ($exams as $course) 
                    <option value="{{$course['id']}}">{{$course['decs']}}</option>
                    @endforeach
                </select>
            </div>

            <div ng-show="isShowSearchForm" class="search-form" >
                <hr/>
                <div class="table-responsive">

                    <form name="searchForm">

                        @if($type=='1')
                        <table>
                            <tr>
                                <td >
                                    <label class="control-label">Số Báo Danh</label>
                                </td>
                                <td>
                                    <input type="text" class="form-control" name="hoten" id="sbd" ng-model="sbd" ng-pattern="regexForNumber">
                                    <div ng-messages="searchForm.sbd.$error" class="error-messages">                                        
                                        <span class="inline-error" ng-message="pattern">Chỉ nhập số 0-9</span>
                                    </div>
                                </td>
                                <td>
                                    <label class="control-label">Họ Và Tên</label>
                                </td>
                                <td>
                                    <input type="text" class="form-control" name="hoten" id="hoten" ng-model="hoten" ng-pattern="regexForSpecChar" >
                                    <div ng-messages="searchForm.hoten.$error" class="error-messages">                                        
                                        <span class="inline-error" ng-message="pattern">Không cho phép nhập ký tự đặc biệt</span>
                                    </div>
                                </td>
                            </tr>
                            <tr>

                                <td class="btn-container" colspan="4">
                                    <hr/>
                                    <input type="button" ng-click="searchMark()" value="Tìm Kiếm" class="btn btn-primary">
                                </td>
                            </tr>
                        </table>
                        @else
                        <table>
                            <tr>
                                <td class="required">
                                    <label class="control-label">Họ Và Tên</label>
                                </td>
                                <td>
                                    <input type="text" class="form-control" name="hoten" id="hoten" ng-model="hoten" ng-pattern="regexForSpecChar" required>
                                    <div ng-messages="searchForm.hoten.$error" class="error-messages">
                                        <span class="inline-error" ng-message="required">Họ và tên không được rỗng</span>
                                        <span class="inline-error" ng-message="pattern">Không cho phép nhập ký tự đặc biệt</span>
                                    </div>
                                </td>
                                <td class="required">
                                    <label class="control-label">Ngày Sinh</label>
                                </td>
                                <td>
                                    <input type="text" class="form-control" id="ngaysinh" name="ngaysinh" ng-model="ngaysinh" ng-pattern="regexForDateTime" placeholder="dd/mm/yyyy" required>
                                    <div ng-messages="searchForm.ngaysinh.$error" class="error-messages">
                                        <span class="inline-error" ng-message="required">Ngày sinh không được rỗng</span>
                                        <span class="inline-error" ng-message="pattern">Ngày sinh không hợp lệ</span>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <label class="control-label">Số Vào Sổ</label>
                                </td>
                                <td>
                                    <input type="text" class="form-control" id="svso" ng-model="sovaoso">
                                </td>
                                <td>
                                    <label class="control-label">Hội Đồng Thi</label>
                                </td>
                                <td>
                                    <input type="text" class="form-control" id="hdthi" ng-model="hdthi">
                                </td>
                            </tr>

                            <tr>
                                <td class="btn-container" colspan="4">
                                    <hr/>
                                    <input type="button" ng-click="searchCert()" value="Tìm Kiếm" class="btn btn-primary">
                                </td>
                            </tr>
                        </table>
                        @endif
                    </form>

                </div>

            </div>
        </div>

        <div  ng-show="isShowSearchResult" class="search-result table-responsive">
            <table class="table table-custom">
                <thead>
                    <tr>                        
                        <th ng-repeat="colField in colFields"><%colField.fielddecs%></th>
                    </tr>
                </thead>
                <tbody>
                    <tr ng-if="searchResult.length > 0" ng-repeat="user in searchResult">
                        <td ng-repeat="value in user"><%value%></td>
                    </tr>
                    <tr ng-if="searchResult.length === 0" >
                        <td>Không Tìm Thấy Thông Tin</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>

</div>

@stop
