<?php

namespace tracuudiem\Providers;

use Illuminate\Support\ServiceProvider;
use tracuudiem\Services\UtilService;
class UtilServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap the application services.
     *
     * @return void
     */
    public function boot()
    {
        //
    }

    /**
     * Register the application services.
     *
     * @return void
     */
    public function register()
    {
         $this->app->bind('tracuudiem\Services\IUtilService', function(){

            return new UtilService();

        });
    }
	  /**
     * Get the services provided by the provider.
     *
     * @return array
     */
    public function provides()
    {
        return ['tracuudiem\Services\IUtilService'];
    }
}
