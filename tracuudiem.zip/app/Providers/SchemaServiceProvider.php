<?php

namespace tracuudiem\Providers;

use Illuminate\Support\ServiceProvider;
use tracuudiem\Services\MySqlSchemaService;
use tracuudiem\Services\SchemaService;


class SchemaServiceProvider extends ServiceProvider
{
    protected $defer = true;
    /**
     * Bootstrap the application services.
     *
     * @return void
     */
    public function boot()
    {
        //
    }

    /**
     * Register the application services.
     *
     * @return void
     */
    public function register()
    {
        $this->app->bind('tracuudiem\Services\ISchemaService', function(){

            return new MySqlSchemaService();

        });
    }
    /**
     * Get the services provided by the provider.
     *
     * @return array
     */
    public function provides()
    {
        return ['tracuudiem\Services\ISchemaService'];
    }
}
