<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 28/3/2016
 * Time: 11:17 PM
 */

namespace tracuudiem\Helper;


class Field
{
    public function __construct()
    {
        echo "Test Class";
    }
}