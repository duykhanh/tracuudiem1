<?php

/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 28/3/2016
 * Time: 10:18 PM
 */

namespace tracuudiem\Services;

use tracuudiem\Services\IUtilService;

interface ISchemaService {

    public function genTableCode($opt = false);

    public function test();

    public function createTable($tableInfo, $colFields);

    public function dropTable($id);

    public function getTableInfoByID($id);

    public function getTableAllInfo($type);

    public function importExcel($filePath, $tableId);

    public function searchCertInfo($tableId, $params);
    
    public function getDisplayCols($id);
}
