<?php

/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 28/3/2016
 * Time: 10:18 PM
 */

namespace tracuudiem\Services;

interface IUtilService {

    public function genrateTableName();
    
    public function validateSearchInputs($params);
    
    public function validateSearchInputForExam($params);
    
    public function validateSettingInputs($params);


    public function validateFileType($file);
    
    public function lowcaseColFields($colFields);
    
    
}
