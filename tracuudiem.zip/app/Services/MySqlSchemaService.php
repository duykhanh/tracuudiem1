<?php

/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 28/3/2016
 * Time: 9:56 PM
 */

namespace tracuudiem\Services;

use Illuminate\Database\Schema\Blueprint;
use Mockery\CountValidator\Exception;
use Illuminate\Support\Facades\Schema;
use tracuudiem\Models\ExamCourses;
use tracuudiem\Models\CourseFields;
use Anhskohbo\UConvert\UConvert;
use Maatwebsite\Excel\Facades\Excel;

class MySqlSchemaService implements ISchemaService {

    public function test() {
        //$this->dropTable(2);
    }

    public function createTable($tableInfo, $colFields) {
        try {
            // Start transaction!
            \DB::beginTransaction();
            //save table 
            $examCourses = new ExamCourses();
            $tableCode = "tb-" . $this->genTableCode();

            $examCourses->ccode = $tableCode;
            $examCourses->decs = $tableInfo['tablename'];
            $examCourses->type = $tableInfo['tabletype'];
            $examCourses->save();
            //save collumns fiedls of table
            $fiedls = [];
            foreach ($colFields as $field) {
                $fiedls[] = new CourseFields(array('ccode' => $tableCode, 'fieldname' => $field['feildName'], 'fielddecs' => $field['feildDesc'], 'fieldtype' => $field['feildType']));
            }
            $examCourses->coursefields()->saveMany($fiedls);

            Schema::create($tableCode, function (Blueprint $table) use($fiedls) {
                $table->increments('id');
                foreach ($fiedls as $field) {
                    switch ($field->fieldtype) {
                        case 1:
                            $table->integer($field->fieldname);
                            break;
                        case 2:
                            $table->string($field->fieldname);
                            break;
                        case 3:
                            $table->date($field->fieldname);
                            break;
                        default:
                            $table->string($field->fieldname);
                    }
                }
            });
            \DB::commit();
            return $examCourses->id;
        } catch (Exception $ex) {
            \DB::rollback();
            throw new Exception($ex->getMessage(), 002);
        }
    }

    public function dropTable($id) {
        try {
            // Start transaction!
            \DB::beginTransaction();
            $examCourses = ExamCourses::find($id);
            Schema::drop($examCourses->ccode);
            $examCourses->delete();

            \DB::commit();
        } catch (Exception $ex) {
            \DB::rollback();
            throw new Exception($ex->getMessage(), 003);
        }
    }

    //  Set to true/false as your default way to do this.
    public function genTableCode($opt = false) {
        if (function_exists('com_create_guid')) {
            if ($opt) {
                return com_create_guid();
            } else {
                return trim(com_create_guid(), '{}');
            }
        } else {
            mt_srand((double) microtime() * 10000);    // optional for php 4.2.0 and up.
            $charid = strtoupper(md5(uniqid(rand(), true)));
            $hyphen = chr(45);    // "-"
            $left_curly = $opt ? chr(123) : "";     //  "{"
            $right_curly = $opt ? chr(125) : "";    //  "}"
            $uuid = $left_curly
                    . substr($charid, 0, 8) . $hyphen
                    . substr($charid, 8, 4) . $hyphen
                    . substr($charid, 12, 4) . $hyphen
                    . substr($charid, 16, 4) . $hyphen
                    . substr($charid, 20, 12)
                    . $right_curly;
            return $uuid;
        }
    }

    public function getTableInfoByID($id) {
        try {
            $examCourses = ExamCourses::find($id);
            $tbInfo['table_name'] = $examCourses->ccode;

            foreach ($examCourses->coursefields as $coursefield) {
                $tbInfo['fields'][] = $coursefield->toArray();
            }

            return $tbInfo;
        } catch (Exception $ex) {
            throw new Exception($ex->getMessage(), 004);
        }
    }

    public function importExcel($filePath, $tableId) {
        try {

            $result = Excel::load($filePath, function($reader) {
                        
                    }, 'UTF-8')->all();

            $tb = $this->getTableInfoByID($tableId);
            \DB::beginTransaction();
            foreach ($result as $sheet) {
                foreach ($sheet as $row) {
                    $row = $row->toArray();
                    $rowInsert = $this->queryInsertBuilder($tb['fields'], $row);

                    \DB::table($tb['table_name'])->insert($rowInsert);
                }
                break;
            }
            \DB::commit();
        } catch (Exception $ex) {
            \DB::rollback();
            throw new Exception($ex->getMessage(), 005);
        }
    }

    public function searchCertInfo($tableId, $params) {
        try {
            $tb = $this->getTableInfoByID($tableId);
            $query = "hoten like '%" . $params['hoten'] . "%' AND DATE(ngaysinh)='" . $params['ngaysinh'] . "'";
            if (isset($params['hdthi'])) {
                $query .=" AND hoidongthi like '%" . $params['hdthi'] . "%'";
            }
            if (isset($params['sovaoso'])) {
                $query .=" AND sovaoso ='" . $params['sovaoso'] . "'";
            }
            //->exclude(['pseudo', 'email', 'age', 'created_at'
            $results = \DB::table($tb['table_name'])->whereRaw($query)->get();

            return $results;
        } catch (Exception $ex) {
            throw new Exception($ex->getMessage(), 006);
        }
    }

    public function searchMarkInfo($params) {
        try {
            $tb = $this->getTableInfoByID($params['id']);
            $query = "";
            if (isset($params['sbd'])) {
                $query = "sbd='" . $params['sbd'] . "'";
                if (isset($params['hoten'])) {
                    $query.=" OR hoten='" . $params['hoten'] . "'";
                }
            } elseif (isset($params['hoten'])) {
                $query = "hoten='" . $params['hoten'] . "'";
            }

            if (empty($query)) {
                return array();
            }

            $results = \DB::table($tb['table_name'])->whereRaw($query)->get();
            return $results;
        } catch (Exception $ex) {
            throw new Exception($ex->getMessage(), 006);
        }
    }

    private function queryInsertBuilder($fieldsInfo, $fieldsContent) {
        try {
            $queryBuilder = array();

            foreach ($fieldsInfo as $field) {
                $convert = new UConvert($fieldsContent[$field['fieldname']], UConvert::TCVN3);
                $value = $convert->transform(UConvert::UNICODE);

                switch ($field['fieldtype']) {
                    case 1:
                        $value = intval($value);
                        break;
                    case 2:
                        $value = $value;
                        break;
                    case 3:
                        $value = date("Y-m-d", strtotime(str_replace('/', '-', $value)));
                        ;
                        break;
                    default:
                        $value = $value;
                }

                $queryBuilder[$field['fieldname']] = $value;
            }
            return $queryBuilder;
        } catch (Exception $ex) {
            throw $ex;
        }
    }

    public function getTableAllInfo($type) {
        $examCourses = ExamCourses::where('type', $type)->get();
        return $examCourses->toArray();
    }

    public function getDisplayCols($id) {
        $tableInfo = $this->getTableInfoByID($id);
        $displayFields = array();
        foreach ($tableInfo['fields'] as $field) {
            $displayFields[]['fielddecs'] = $field['fielddecs'];
        }
        return $displayFields;
    }

}
