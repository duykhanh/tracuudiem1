<?php

/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 28/3/2016
 * Time: 10:18 PM
 */

namespace tracuudiem\Services;

class UtilService implements IUtilService {

    function genrateTableName() {
        $tableName = "tbn_" . time();
        return $tableName;
    }

    public function validateSearchInputs($params) {
        $errMgs = array();
        $regexSpec = '/[#$%^&*()+=\-\[\]\';,.\/{}|":<>?~\\\\]/';
        $regexDate = '@^(0[1-9]|[12][0-9]|3[01])/(0[1-9]|1[012])/(19|20)\d\d$@';

        if (!isset($params['id']) || !$params['id']) {
            $errMgs[] = "Trường id không được định nghĩa";
        }

        if (!isset($params['hoten']) || !$params['hoten']) {
            $errMgs[] = "Trường Họ và Tên không được rỗng";
        }

        if (preg_match($regexSpec, $params['hoten'])) {
            $errMgs[] = "Trường Họ Tên không nhập những ký tự đặc biệt";
        }

        if (!isset($params['ngaysinh']) || !$params['ngaysinh']) {
            $errMgs[] = "Trường Ngày Sinh không được rỗng";
        }

        if (!preg_match($regexDate, $params['ngaysinh'])) {
            $errMgs[] = "Trường Ngày Sinh không không hợp lệ";
        }

        if (!isset($params['sovaoso']) || empty($params['sovaoso'])) {
            if (isset($params['sovaoso'])) {
                unset($params['sovaoso']);
            }
        } elseif (preg_match($regexSpec, $params['sovaoso'])) {
            $errMgs[] = "Trường Số Vào Sổ không nhập những ký tự đặc biệt";
        }

        if (!isset($params['hdthi']) || empty($params['hdthi'])) {
            if (isset($params['hdthi'])) {
                unset($params['hdthi']);
            }
        } elseif (preg_match($regexSpec, $params['hdthi'])) {
            $errMgs[] = "Trường Hội Đồng Thi không nhập những ký tự đặc biệt";
        }

        return $errMgs;
    }

    public function validateSearchInputForExam($params) {
        $errMgs = array();
        $regexSpec = '/[#$%^&*()+=\-\[\]\';,.\/{}|":<>?~\\\\]/';
        $regexNum = '/^[0-9]*$/';

        if (!isset($params['id']) || empty($params['id'])) {
            $errMgs[] = "Bạn chưa chọn đợt thi";
        } else if (!preg_match($regexNum, $params['id'])) {
            $errMgs[] = "ID phải là kiểu số";
        }

        if (isset($params['sbd']) && !empty($params['sbd'])) {
            if (!preg_match($regexNum, $params['sbd'])) {
                $errMgs[] = "sbd phải là kiểu số";
            }
        }


        if (isset($params['hoten'])) {
            if (preg_match($regexSpec, $params['hoten'])) {
                $errMgs[] = "Trường Họ Tên không nhập những ký tự đặc biệt";
            }
        }
        return $errMgs;
    }

    public function validateFileType($file) {

        $arrayExtensions = array("xls", "xlsx");

        $extension = $file->getClientOriginalExtension();

        if (in_array($extension, $arrayExtensions)) {
            return true;
        }
        return false;
    }

    public function lowcaseColFields($colFields) {
        $fieldTemps = array();
        foreach ($colFields as $field) {
            $fieldTem = $field;
            $fieldTem['feildName'] = strtolower($field['feildName']);
            $fieldTemps[] = $fieldTem;
        }
        return $fieldTemps;
    }

    public function validateSettingInputs($params) {
        $errMgs = array();
        $regexSpec = '/[#$%^&*()+=\-\[\]\';,.\/{}|":<>?~\\\\]/';


        $tableInfo = $params->except('colfields');
        $colFields = $params->input('colfields');

        if (!$tableInfo && count($tableInfo) == 0) {
            $errMgs[] = array("Thông tin đợt thi hoặc văn bằng bị thiếu");
        }

        //validate table name
        if (empty(trim($tableInfo['tablename']))) {
            $errMgs[] = array("Tên bảng không thể rỗng");
        }

        if (preg_match($regexSpec, $tableInfo['tablename'])) {
            $errMgs[] = "Trường tên bảng không cho phép nhập những ký tự đặc biệt";
        }

        if (count($colFields) == 0) {
            $errMgs[] = array("Thông tin trường bị thiếu");
        }

        //$colFields[]=array("feildName"=>"'fdsf$5","feildDesc"=>"@%#%^");

        foreach ($colFields as $field) {
            if (preg_match($regexSpec, $field['feildName'])) {
                $errMgs[] = "Nội dung <strong>" . $field['feildName'] . "</strong> không hợp lệ. Tên trường không cho phép nhập những ký tự đặc biệt";
            }

            if (preg_match($regexSpec, $field['feildDesc'])) {
                $errMgs[] = "Nội dung <strong>" . $field['feildDesc'] . "</strong> không hợp lệ. Tên Hiển thị không cho phép nhập những ký tự đặc biệt";
            }
        }

        return $errMgs;
    }

}
