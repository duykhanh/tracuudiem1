<?php

namespace tracuudiem\Models;

use Illuminate\Database\Eloquent\Model;

class ExamCourses extends Model {

    //
    protected $table = 'exam_courses';
    protected $hidden = [
        'ccode', 'created_at', 'updated_at'
    ];
    protected $fillable = ['ccode', 'decs'];

    public function coursefields() {
        return $this->hasMany('tracuudiem\Models\CourseFields', 'ccode', 'ccode');
    }

    public function delete() {
        // delete all related coursefields 
        $this->coursefields()->delete();
        // as suggested by Dirk in comment,
        // it's an uglier alternative, but faster        
        // delete the user
        return parent::delete();
    }

}
