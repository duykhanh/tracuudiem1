<?php

namespace tracuudiem\Models;

use Illuminate\Database\Eloquent\Model;

class CertInfo extends Model
{
    protected $table = 'trcvb';
    /**
     * The attributes excluded from the model's JSON form.
     *
     * @var array
     */
    protected $hidden = [
        'ntotnghiep'
    ];
}
