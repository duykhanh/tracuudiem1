<?php

namespace tracuudiem\Models;

use Illuminate\Database\Eloquent\Model;

class CourseFields extends Model
{
    //
	protected $table="course_fields";
	protected $fillable = [
        'ccode', 'fieldname', 'fielddecs','fieldtype',
    ];
	protected $hidden = [
        'id','created_at','updated_at'
    ];
	 /**
     * Get the examcourse that owns the course_fields.
     */
    public function post()
    {
        return $this->belongsTo('tracuudiem\Models\ExamCourses','ccode');
    }
}
