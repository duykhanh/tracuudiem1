<?php

namespace tracuudiem\Events;

abstract class Event
{
    //
}
