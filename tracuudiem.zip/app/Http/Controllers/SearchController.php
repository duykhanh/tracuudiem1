<?php

/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 22/3/2016
 * Time: 9:30 PM
 */

namespace tracuudiem\Http\Controllers;

use Illuminate\Http\Request;
use tracuudiem\Services\IUtilService;
use tracuudiem\Services\ISchemaService;

class SearchController extends Controller {

    public function __construct() {
        //$this->middleware('guest');
    }

    public function index(ISchemaService $mySqlShemaService, $type) {
        if (!isset($type)) {
            $type = 2;
        }
        $result = $mySqlShemaService->getTableAllInfo($type);
        return view('search')->with('exams', $result)->with('type', $type);
    }

    public function searchMarks(Request $request, ISchemaService $mySqlShemaService, IUtilService $utilService) {
        $header = array(
            'Content-Type' => 'application/json; charset=UTF-8',
            'charset' => 'utf-8'
        );
        try {

            $params = $request->all();
            $errMgs = $utilService->validateSearchInputForExam($params);

            if (count($errMgs) > 0) {
                return response()->json(array('success' => 'false', 'error-messages' => $errMgs), 200, $header, JSON_UNESCAPED_UNICODE);
            }

            $resultsTemp = $mySqlShemaService->searchMarkInfo($params);
            $results = array();
            foreach ($resultsTemp as $res) {
                unset($res['id']);
                $results[] = $res;
            }

            return response()->json(array('success' => 'true', 'data' => $results), 200, $header, JSON_UNESCAPED_UNICODE);
        } catch (Exception $ex) {
            return response()->json(array('success' => 'false', 'error-message' => 'Xảy ra lỗi không mong muốn khi lấy thông tin'), 200, $header, JSON_UNESCAPED_UNICODE);
        }
    }

    public function searchCerts(Request $request, ISchemaService $mySqlShemaService, IUtilService $utilService) {
        $header = array(
            'Content-Type' => 'application/json; charset=UTF-8',
            'charset' => 'utf-8'
        );
        try {

            $errMgs = $utilService->validateSearchInputs($request->all());
            if (count($errMgs) > 0) {
                return response()->json(array('success' => 'false', 'error-messages' => $errMgs), 200, $header, JSON_UNESCAPED_UNICODE);
            }
            $id = $request->only('id');
            $params = $request->except('id');
            $params['ngaysinh'] = date("Y-m-d", strtotime(str_replace('/', '-', $params['ngaysinh'])));

            $resultsTemp = $mySqlShemaService->searchCertInfo(intval($id['id']), $params);
            $results = array();
            foreach ($resultsTemp as $res) {
                unset($res['id']);
                $results[] = $res;
            }

            return response()->json(array('success' => 'true', 'data' => $results), 200, $header, JSON_UNESCAPED_UNICODE);
        } catch (Exception $ex) {
            return response()->json(array('success' => 'false', 'error-message' => 'Xảy ra lỗi không mong muốn khi lấy thông tin'), 200, $header, JSON_UNESCAPED_UNICODE);
        }
    }

    public function getColInfo(Request $request, ISchemaService $mySqlShemaService) {
        $header = array(
            'Content-Type' => 'application/json; charset=UTF-8',
            'charset' => 'utf-8'
        );
        try {
            $params = $request->only('id');

            if (!isset($params['id']) && empty($params['id'])) {
                return response()->json(array('success' => 'false', 'error-message' => 'id không được định nghĩa'), 200, $header, JSON_UNESCAPED_UNICODE);
            }
            $colInfos = $mySqlShemaService->getDisplayCols($params['id']);


            return response()->json(array('success' => 'true', 'data' => $colInfos), 200, $header, JSON_UNESCAPED_UNICODE);
            //return array('success' => 'true', 'data' => $tableInfo['fields']);
        } catch (Exception $ex) {

            return response()->json(array('success' => 'false', 'error-message' => 'Xảy ra lỗi không mong muốn khi lấy thông tin'), 200, $header, JSON_UNESCAPED_UNICODE);
        }
    }

}
