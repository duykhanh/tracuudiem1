<?php

/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 21/4/2016
 * Time: 8:23 PM
 */

namespace tracuudiem\Http\Controllers;

use tracuudiem\Services\ISchemaService;
use Illuminate\Http\Request;
use tracuudiem\Services\IUtilService;

class SettingController extends Controller {

    public function __construct() {
        $this->middleware('auth');
    }

    public function index() {

        return View('setting');
    }

    public function store(Request $request, ISchemaService $mySqlShemaService, IUtilService $utilService) {
        //get parameters from request
        $header = array(
            'Content-Type' => 'application/json; charset=UTF-8',
            'charset' => 'utf-8'
        );

        try {
            
            $errMgs = $utilService->validateSettingInputs($request);

            if (count($errMgs) > 0) {
                return response()->json(array('success' => 'false', 'errors' => $errMgs), 200, $header, JSON_UNESCAPED_UNICODE);
            }

            $tableInfo = $request->except('colfields');
            $colFields = $utilService->lowcaseColFields($request->input('colfields'));
            $tableInfo['ccode']= $utilService->genrateTableName();
            //validate for colFields array
            $id = $mySqlShemaService->createTable($tableInfo, $colFields);
            return response()->json(array('success' => 'true', 'id' => $id), 200, $header, JSON_UNESCAPED_UNICODE);
        } catch (Exception $ex) {
            return response()->json(array('success' => 'false', 'errors' => array('Xảy ra lỗi không mong muốn khi lấy thông tin')), 200, $header, JSON_UNESCAPED_UNICODE);
        }
    }
    
    

}
