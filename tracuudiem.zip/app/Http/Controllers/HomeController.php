<?php

/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 22/3/2016
 * Time: 9:30 PM
 */

namespace tracuudiem\Http\Controllers;

use tracuudiem\Services\ISchemaService;
use Illuminate\Http\Request;

class HomeController extends Controller {

    public function __construct(ISchemaService $mySqlShemaService) {


        $this->middleware('auth');
    }

    public function index(Request $request, ISchemaService $mySqlShemaService) {

        
        return view('home');
    }

    public function store(Request $request, ISchemaService $mySqlShemaService) {
        //get parameters from request
        $tableName = $request->input('tablename', '');
        $colFields = $request->input('colfields', array());
        $errorMessagses = [];

        //validate table name
        if (empty(trim($tableName))) {
            $errorMessagses = array("code" => 001, "Tên bảng không thể rỗng");
        }
        //validate for colFields array
        $id = $mySqlShemaService->createTable($tableName, $colFields);
        return array('success' => 'true', 'id' => $id);
    }

}
