<?php

/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 27/3/2016
 * Time: 8:46 AM
 */

namespace tracuudiem\Http\Controllers;

use Illuminate\Http\Request;
use tracuudiem\Repositories\ImportCertificatesInfo;
use Illuminate\Support\Facades\Input;
use tracuudiem\Services\ISchemaService;
use tracuudiem\Services\IUtilService;

class UploadController extends Controller {

    protected $importCertInfo;

    public function __construct(ImportCertificatesInfo $importCertInfo) {
        $this->importCertInfo = $importCertInfo;
        $this->middleware('auth');
    }

    public function index() {
        return View('welcome');
    }

    public function upload(Request $request, ISchemaService $mySqlShemaService, IUtilService $utilService) {
        $header = array(
            'Content-Type' => 'application/json; charset=UTF-8',
            'charset' => 'utf-8'
        );
        $errMgs = array();
        try {
            ini_set('max_execution_time', 300);
            $tableId = Input::input('table_id');
            $tableType = Input::input('table_type');
            $input = Input::file('file');
            if (!isset($tableId)) {
                $errMgs[] = "Id không được định nghĩa";
            }

            if (!$input || !isset($input)) {
                $errMgs[] = "File không được định nghĩa";
            }
            $filename = $input->getRealPath();

            if (!$filename) {
                $errMgs[] = "Tên file bị rỗng ";
            }
            
            if (!$utilService->validateFileType($input)) {
                $errMgs[] = "Kiểu tập tin không hợp lệ";
            }            

            if (count($errMgs) > 0) {
                return response()->json(array('success' => 'false', 'errors' => $errMgs), 200, $header, JSON_UNESCAPED_UNICODE);
            }

            $mySqlShemaService->importExcel($filename, intval($tableId));
            unlink($filename);
            
            return response()->json(array('success' => 'true', 'redirect' => '/cert/'.$tableType), 200, $header, JSON_UNESCAPED_UNICODE);
        } catch (Exception $ex) {
            $errMgs[] = "Xảy ra lỗi không mong muốn khi lấy thông tin";
            return response()->json(array('success' => 'false', 'errors' => $errMgs), 200, $header, JSON_UNESCAPED_UNICODE);
        }
    }

}
