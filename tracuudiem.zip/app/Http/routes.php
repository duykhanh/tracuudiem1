<?php

/*
  |--------------------------------------------------------------------------
  | Routes File
  |--------------------------------------------------------------------------
  |
  | Here is where you will register all of the routes in an application.
  | It's a breeze. Simply tell Laravel the URIs it should respond to
  | and give it the controller to call when that URI is requested.
  |
 */

Route::get('/', function () {
    return view('welcome');
});


/*
  |--------------------------------------------------------------------------
  | Application Routes
  |--------------------------------------------------------------------------
  |
  | This route group applies the "web" middleware group to every route
  | it contains. The "web" middleware group is defined in your HTTP
  | kernel and includes session state, CSRF protection, and more.
  |
 */

Route::group(['middleware' => ['web']], function () {
    Route::resource('home', 'HomeController');
    Route::resource('setting', 'SettingController');
    Route::get('test', 'UploadController@index');
    Route::any('upload', 'UploadController@upload');
    Route::any('cert/{type?}',['as'=>'search','uses'=>'SearchController@index']);
    Route::any('search-certs', 'SearchController@searchCerts');
    Route::any('search-exam', 'SearchController@searchMarks');
    Route::any('get-col-info', 'SearchController@getColInfo');
    Route::controllers([
        'auth' => 'Auth\AuthController',
        'password' => 'Auth\PasswordController',
        
    ]);
});

