<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 26/3/2016
 * Time: 4:04 PM
 */

namespace tracuudiem\Repositories;

use tracuudiem\Models\CertInfo;

class ImportCertificatesInfo extends BaseRepository
{
    public function import(){

    }
}