/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */




var adjustHeight = function () {
    var headerH = $('header').outerHeight() ? parseInt($('header').outerHeight(true)) : 0;
    var footerH = $('footer').outerHeight() ? parseInt($('footer').outerHeight(true)) : 0;
    var navFooterH = $('.nav-bottom').outerHeight(true) ? parseInt($('.nav-bottom').outerHeight(true)) : 0;

    $('.main-content').css('min-height', $(window).height() - (headerH + footerH + navFooterH) + "px");
}

//$(window).load(adjustHeight);
//$(window).resize(adjustHeight);

$.fn.extend({
    loading: function () {
        console.log($(this));
        var divTemp = "<div class='loading-mask'><img id='loading' src='" + BASIC_URL + "/images/gif-load.gif'></div>";
        this.append(divTemp);
        var divMask = this.find(".loading-mask");
        if ($(this).is('body')) {
            $(divMask).css({'z-index': '9999', 'width': '100%', 'height': '100%', 'position': 'fixed', 'top': '0px', 'left': '0px'});
            $(this).css({'overflow': 'hidden'});
        } else if ($(this).css('position') !== null && $(this).css('position') !== 'initial' && $(this).css('position') !== 'static') {
            $(divMask).css({'z-index': '9999', 'width': '100%', 'height': '100%', 'position': 'absolute', 'top': '0px', 'left': '0px'});
        } else {
            
            $(this).attr('cus-position', 'relative');
            $(this).css({'position': 'relative'});
            $(divMask).css({'z-index': '9999', 'width': '100%', 'height': '100%', 'position': 'absolute', 'top': '0px', 'left': '0px'});
        }

    },
    unloading: function () {
        var divMask = this.find(".loading-mask");

        if (typeof divMask !== 'undefined') {
            if ($(this).is('body')) {
                $(this).removeAttr('style');
            } else if ($(this).attr('cus-position')) {
                $(this).removeAttr('cus-position');
                $(this).css({'position': ''});
                $(divMask).hide();
            }
        }

    }
})


/*var mySearchModule = angular.module('searchModule', [])

mySearchModule.directive('loading', ['$http', function ($http)
    {
        return {
            restrict: 'AC',
            link: function (scope, elm, attrs)
            {
                console.log(elm);
                scope.isLoading = function () {
                    return $http.pendingRequests.length > 0;
                };

                scope.$watch(scope.isLoading, function (v)
                {
                    if (v) {
                        $(elm).loading();
                    } else {
                        $(elm).unloading();
                    }
                });
            }
        };

    }]);*/