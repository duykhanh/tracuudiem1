/**
 * Created by khanhnguyen on 21/4/2016.
 */
// Code goes here

var mySearchModule = angular.module('searchModule', ['ngMessages'], function ($interpolateProvider) {
    $interpolateProvider.startSymbol('<%');
    $interpolateProvider.endSymbol('%>');
});
mySearchModule.constant("BASIC_URL", BASIC_URL)
mySearchModule.controller('searchController', ['$scope', 'getSearchService', function ($scope, getSearchService) {
        $scope.isShowSearchForm = false;
        $scope.isShowSearchResult = false;
        $scope.selectedCourse = "-1";
        $scope.regexForSpecChar = '[^!@#$%^&*(){}\\[\\]\'\\\"]*';
        $scope.regexForDateTime = '^(0?[1-9]|[12][0-9]|3[01])/(0?[1-9]|1[012])/((19|20)\\d\\d)$';
        $scope.regexForNumber = '^[0-9]*$';
        $scope.selectedCourses = [];
        $scope.colFields = [{'fielddecs': 'Ho va ten'}, {'fielddecs': 'Ngay sinh'}];
        $scope.isLoading = false;
        $scope.searchResult = [];


        $scope.$watch('selectedCourse', function (newValue, oldValue) {
            if (parseInt(newValue) !== -1) {
                $scope.isShowSearchForm = true;
            } else {
                $scope.isShowSearchForm = false;
            }

        });

        $scope.search = function () {

            if (!$scope.searchForm.$valid) {
               
                return false;
            }
            

        };

        $scope.validationForm = function () {

            //check empty or null $scope.hoten
            if ($scope.hoten === null || $scope.hoten === "") {
                return false;
            }
            //Special char


            return true;
        };

        $scope.searchCert = function () {


            if (!$scope.searchForm.$valid) {

                return false;
            }
            var $params = {
                'id': $scope.selectedCourse,
                'hoten': $scope.hoten,
                'ngaysinh': $scope.ngaysinh,
                'sovaoso': $scope.sovaoso,
                'hoidongthi': $scope.hoidongthi
            }
            var action = 'search-certs';
            getSearchService.search($params, action, function ($result) {
                var res = $result.data;
                if (res.success === "true") {
                    $scope.searchResult = res.data;
                    $scope.isShowSearchResult = true;
                } else {
                    console.log("Error");
                }

            });
        };

        $scope.searchMark=function(){
            console.log("search mark");
            if (!$scope.searchForm.$valid) {
                return false;
            }
            var action = 'search-exam';
            var $params = {
                'id': $scope.selectedCourse,
                'sbd':$scope.sbd,
                'hoten': $scope.hoten,                
            }
            
            getSearchService.search($params, action, function ($result) {
                var res = $result.data;
                if (res.success === "true") {
                    $scope.searchResult = res.data;
                    $scope.isShowSearchResult = true;
                } else {
                    console.log("Error");
                }

            });
        }
        
        $scope.getColInfo = function () {
            if ($scope.selectedCourse === "-1") {
                return false;
            }
            var $params = {
                'id': $scope.selectedCourse
            };
            $scope.colFields = [];
            $scope.isLoading = true;
            getSearchService.getColInfo($params, function ($result) {
                var res = $result.data;
                if (res.success === "true") {
                    for (var i = 0; i < res.data.length; i++) {
                        var colTemp = {'fielddecs': res.data[i].fielddecs};
                        $scope.colFields.push(colTemp);
                    }
                } else {
                    console.log('error');
                }
                $scope.isLoading = false;

            });
        };
    }]);



mySearchModule.factory('getSearchService', ['$http', 'BASIC_URL', function ($http, BASIC_URL) {
        return {
            search: function (params, action, success, error) {
                //firing ajax request
                $http({
                    method: 'GET',
                    //setting url for search ( we have this route in routes.php )
                    url: BASIC_URL + '/' + action,
                    //setting object inside param function that will be sent
                    params: params,
                    headers: {
                        'X-Requested-With': 'XMLHttpRequest'
                    }

                }).then(success, error);

            },
            getColInfo: function (params, success, error) {
                $http({
                    method: 'Get',
                    url: BASIC_URL + '/get-col-info',
                    params: params,
                    headers: {
                        'X-Requested-With': 'XMLHttpRequest'
                    }
                }).then(success, error);

            }
        };
    }]);
mySearchModule.directive('loading', ['$http', function ($http)
    {
        return {
            restrict: 'AC',
            link: function (scope, elm, attrs)
            {               
                scope.isLoading = function () {
                    return $http.pendingRequests.length > 0;
                };

                scope.$watch(scope.isLoading, function (v)
                {
                   
                    if (v) {
                        $(elm).loading();
                    } else {
                        $(elm).unloading();
                    }
                });
            }
        };

    }]);