/**
 * Created by khanhnguyen on 21/4/2016.
 */
// declare a module
var myAppModule = angular.module('searchModule', ['ngMessages','ngSanitize'], function ($interpolateProvider) {
    $interpolateProvider.startSymbol('<%');
    $interpolateProvider.endSymbol('%>');
});
myAppModule.constant("CSRF_TOKEN", '<%!! csrf_token() !!%>');
myAppModule.constant("BASIC_URL", BASIC_URL);
myAppModule.controller('genTableCtrl', ['$scope', 'generateTableService', 'fileUploadService', function ($scope, generateTableService, fileUploadService) {
        $scope.colField = [{feildName: '', feildDesc: '', feildType: 'int'}];
        $scope.colFields = [];
        $scope.dataTypes = [{
                id: 1,
                label: 'Số'
            }, {
                id: 2,
                label: 'Chuỗi'
            },
            {
                id: 3,
                label: 'Ngày'
            }
        ];
        $scope.feildType = "1";
        $scope.typeOfTable = "1";
        $scope.regexForTN = '[^!@#$%^&*(){}\\[\\]\'\\\"]*';
        $scope.isExistColField = false;
        $scope.isShowErrMgs = false;
        $scope.errMgs = [];
        $scope.isShowfrmCreateTN = true;
        $scope.isShowfrmAddCol = false;
        $scope.isShowfrmImportExcel = false;
        $scope.isLoading = false;
        $scope.tableId = "";

        $scope.addTableName = function () {
            $scope.isShowfrmCreateTN = false;
            $scope.isShowfrmAddCol = true;
        }

        $scope.addCollumn = function () {

            //validate here
            if (!$scope.isValidColN || !$scope.frmAddCols.$valid) {
                return false;
            }
            $scope.isExistColField = false;
            if ($scope.isExistColName()) {
                $scope.isExistColField = true;
                return false;
            }

            //Add Collumn 
            $scope.colFields.push({feildName: $scope.feildName, feildDesc: $scope.feildDesc, feildType: $scope.feildType});

            $scope.resetFrom();

        };

        $scope.saveTable = function () {
            if (!$scope.isSave())
                return false;
            $scope.isLoading = true;
            generateTableService.createTable($scope.tableName, $scope.typeOfTable, $scope.colFields, function ($result) {
                $scope.isLoading = false;
                if ($result.data.success === "true") {
                    $scope.isShowfrmCreateTN = false;
                    $scope.isShowfrmAddCol = false;
                    $scope.isShowfrmImportExcel = true;
                    $scope.tableId = $result.data.id;
                } else {
                    $scope.isShowErrMgs = true;
                    $scope.errMgs = $result.data.errors;
                }

                
            });
        }


        $scope.resetFrom = function () {
            $scope.feildName = "";
            $scope.feildDesc = "";
            $scope.feildType = "1";
        }
        $scope.$watch('feildName', function (newValue, oldValue) {
            var regex = /(^[A-Za-z])([a-z0-9_]{1,30}$)/;
            if (!newValue) {
                $scope.isValidColN = false;

            } else {
                if (regex.test(newValue)) {
                    $scope.isValidColN = true;
                } else {
                    $scope.isValidColN = false;

                }
            }

        });
        $scope.isExistColName = function () {
            if ($scope.colFields.length === 0) {
                return false;
            }
            for (var i = 0; i < $scope.colFields.length; i++) {
                if ($scope.colFields[i].feildName === $scope.feildName)
                {
                    return true;
                }
            }
            return false;

        }

        $scope.getFieldName = function (id) {

            var typeDecs = "";
            for (var i = 0; i < $scope.dataTypes.length; i++) {
                if ($scope.dataTypes[i].id === parseInt(id))
                {
                    typeDecs = $scope.dataTypes[i].label;
                    break;
                }
            }

            return typeDecs;
        }

        $scope.deleteField = function (index) {
            $scope.colFields.splice(index, 1);
        }

        $scope.isSave = function () {
            if ($scope.colFields.length > 0) {
                return true;
            } else {
                return false;
            }
        }

        $scope.uploadFile = function () {
            var file = $scope.myFile;
            $scope.isLoading = true;
            fileUploadService.importExcel($scope.tableId,$scope.typeOfTable, file, function ($result) {
                $scope.isLoading = false;
                if($result.data.success==="false"){
                    $scope.isShowErrMgs = true;
                    $scope.errMgs = $result.data.errors;
                }else{
                    window.location.href=BASIC_URL+$result.data.redirect;
                }
            });
        };

    }]);

myAppModule.factory('generateTableService', ['$http', 'BASIC_URL', function ($http, BASIC_URL) {
        return {
            createTable: function (tableName, tableType, colFields, success, error) {
                //firing ajax request
                $http({
                    method: 'POST',
                    //setting url for search ( we have this route in routes.php )
                    url: BASIC_URL + '/setting',
                    //setting object inside param function that will be sent 
                    data: {
                        'tablename': tableName,
                        'tabletype': tableType,
                        'colfields': colFields

                    }
                }).then(success);

            }

        }
    }]);

myAppModule.factory('fileUploadService', ['$http', 'BASIC_URL', function ($http, BASIC_URL) {
        return {
            importExcel: function (tableID,tableType, file, success, error) {

                var fd = new FormData();
                fd.append('table_id', tableID);
                fd.append('table_type', tableType);
                fd.append('file', file);
                
                //firing ajax request


                $http.post(BASIC_URL + '/upload', fd, {
                    transformRequest: angular.identity,
                    headers: {'Content-Type': undefined}
                }).then(success, error);


            }
        }
    }]);

myAppModule.directive('fileModel', ['$parse', function ($parse) {
        return {
            restrict: 'A',
            link: function (scope, element, attrs) {
                var model = $parse(attrs.fileModel);
                var modelSetter = model.assign;
                element.bind('change', function () {
                    scope.$apply(function () {
                        modelSetter(scope, element[0].files[0]);
                        var regex = /(?!.*[.](?:xlsx|xls)$).*/;
                        scope.filePath = element[0].files[0].name;
                        if (regex.test(scope.filePath)) {
                            scope.isValidFile = true;
                        } else {
                            scope.isValidFile = false;
                        }
                    });


                });
            }
        };
    }]);

myAppModule.directive('loading', ['$http', function ($http)
    {
        return {
            restrict: 'AC',
            link: function (scope, elm, attrs)
            {
                scope.isLoading = function () {
                    return $http.pendingRequests.length > 0;
                };
                scope.$watch(scope.isLoading, function (v)
                {
                    if (v) {
                        $(elm).loading();
                    } else {
                        $(elm).unloading();
                    }
                });
            }
        };

    }]);



